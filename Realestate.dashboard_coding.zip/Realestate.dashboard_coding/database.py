import sqlite3

def create_connection():
    conn = sqlite3.connect("real_estate.db")
    return conn

def save_data(df):
    conn = create_connection()
    df.to_sql("properties", conn, if_exists="replace", index=False)
    conn.close()

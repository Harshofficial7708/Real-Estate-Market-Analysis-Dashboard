import streamlit as st
import pandas as pd
import plotly.express as px
from data_processing import load_data
from visualization import plot_heatmap
from streamlit_folium import folium_static
from prediction import train_model  # Import the prediction model
from database import save_data  # Import the database function

st.set_page_config(layout="wide")

st.title("🏡 Real Estate Market Analysis Dashboard")

# Load data from the given file path
DEFAULT_FILEPATH = "C:/portugal_listinigs.csv"

# Try to load default dataset
df = None

try:
    df = load_data(DEFAULT_FILEPATH)
    st.write("✅ **Loaded Default Dataset:**", DEFAULT_FILEPATH)
except Exception as e:
    st.warning(f"⚠️ Could not load default dataset: {e}")

# Upload dataset (optional)
uploaded_file = st.file_uploader("Or Upload Your Own CSV File", type=["csv"])

if uploaded_file:
    df = load_data(uploaded_file)
    st.write("📂 **Using Uploaded Dataset**")

if df is not None:
    st.write("### Data Preview", df.head())

    # Visualization - Property Price Distribution
    st.subheader("📊 Property Price Distribution")
    fig = px.histogram(df, x="Price", nbins=50, title="Distribution of Property Prices")
    st.plotly_chart(fig)

    # District-wise price analysis
    st.subheader("📍 Average Price by District")
    avg_price = df.groupby("District")["Price"].mean().reset_index()
    fig = px.bar(avg_price, x="District", y="Price", title="Average Price per District", color="Price")
    st.plotly_chart(fig)

    # Heatmap Visualization
    st.subheader("🌍 Property Price Heatmap")
    st_map = plot_heatmap(df)
    folium_static(st_map)

    # Sidebar - Rental Yield Calculator
    st.sidebar.subheader("🏠 Rental Yield Calculator")

    price = st.sidebar.number_input("Property Price (€)", min_value=0)
    rent = st.sidebar.number_input("Monthly Rent (€)", min_value=0)

    if price > 0 and rent > 0:
        rental_yield = (rent * 12 / price) * 100
        st.sidebar.write(f"📊 **Estimated Rental Yield:** {rental_yield:.2f}%")

    # Train the Machine Learning Model for Price Prediction
    st.sidebar.subheader("🏡 Price Prediction")
    model = train_model(df)  # Train the model

    area = st.sidebar.number_input("Total Area (sq m)", min_value=10)
    bedrooms = st.sidebar.number_input("Bedrooms", min_value=1)
    bathrooms = st.sidebar.number_input("Bathrooms", min_value=1)

    if st.sidebar.button("Predict Price"):
        pred_price = model.predict([[area, area * 0.8, bedrooms, bathrooms]])
        st.sidebar.write(f"💰 **Estimated Property Price:** €{pred_price[0]:,.2f}")

    # Save Data to Database
    if st.button("💾 Save Data"):
        save_data(df)
        st.success("✅ Data saved successfully!")

else:
    st.error("❌ No data available. Please upload a CSV file.")

import pandas as pd
x=pd.read_csv("C:\portugal_listinigs.csv")
print(x)
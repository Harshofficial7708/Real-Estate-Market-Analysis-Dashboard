from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

def train_model(df):
    """Train a model to predict property prices"""
    X = df[['TotalArea', 'LivingArea', 'NumberOfBedrooms', 'NumberOfBathrooms']]
    y = df["Price"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=100)
    model.fit(X_train, y_train)

    return model

import folium
from streamlit_folium import folium_static

def plot_heatmap(df):
    """Plot heatmap of property prices"""
    m = folium.Map(location=[38.7, -9.1], zoom_start=7)  # Centered in Portugal

    for _, row in df.iterrows():
        folium.CircleMarker(
            location=[row.get("Latitude", 38.7), row.get("Longitude", -9.1)],
            radius=5,
            color="red",
            fill=True,
            fill_opacity=0.7
        ).add_to(m)

    return m

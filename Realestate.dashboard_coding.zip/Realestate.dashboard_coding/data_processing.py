import pandas as pd

def load_data(filepath="C:/portugal_listinigs.csv"):
    """Load real estate data from CSV"""
    df = pd.read_csv(filepath, low_memory=False)

    # Select relevant columns
    df = df[['Price', 'District', 'City', 'Type', 'TotalArea', 'LivingArea',
             'NumberOfBedrooms', 'NumberOfBathrooms', 'LotSize']]

    # Drop rows with missing prices
    df = df.dropna(subset=['Price'])

    # Fill missing values with median values
    for col in ['TotalArea', 'LivingArea', 'NumberOfBedrooms', 'NumberOfBathrooms', 'LotSize']:
        df[col] = df[col].fillna(df[col].median())

    return df

# Load and preview the data
df = load_data("C:/portugal_listinigs.csv")
print(df.head())

